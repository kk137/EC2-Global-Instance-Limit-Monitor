import json
import boto3

def lambda_handler(event, context):
    ec2 = boto3.client('ec2')
    cloudwatch = boto3.client('cloudwatch')
    sns = boto3.client('sns')
    
    instance_id = event['detail']['instance-id']
    
    # Count all running instances (excluding the new one)
    all_instances = ec2.describe_instances(
        Filters=[
            {'Name': 'instance-state-name', 'Values': ['running']}
        ]
    )
    
    existing_count = 0
    for reservation in all_instances['Reservations']:
        for inst in reservation['Instances']:
            if inst['InstanceId'] != instance_id:
                existing_count += 1
    
    total_count = existing_count + 1
    
    # Check global limit (12 instances total)
    if existing_count >= 12:
        # Tag the violating instance
        ec2.create_tags(
            Resources=[instance_id],
            Tags=[
                {'Key': 'ViolationReason', 'Value': 'Exceeded global instance limit'},
                {'Key': 'ViolationTime', 'Value': str(context.aws_request_id)},
                {'Key': 'GlobalLimit', 'Value': '12'}
            ]
        )
        
        # Send CloudWatch metric
        cloudwatch.put_metric_data(
            Namespace='EC2/GlobalMonitoring',
            MetricData=[
                {
                    'MetricName': 'ViolationStatus',
                    'Value': 1
                }
            ]
        )
        
        # Send SNS notification
        message = f"""
EC2 Instance Limit Exceeded Alert

Instance ID: {instance_id}
Total Running Instances: {total_count}
Global Limit: 12
Violation Time: {context.aws_request_id}

The new instance has been tagged for identification.
Please review and take appropriate action.
        """
        
        sns.publish(
            TopicArn='arn:aws:sns:us-west-2:345594601181:EC2-Instance-Limit-Alerts',
            Subject='EC2 Instance Limit Exceeded',
            Message=message
        )
    
    # Always send total instance count metric
    cloudwatch.put_metric_data(
        Namespace='EC2/GlobalMonitoring',
        MetricData=[
            {
                'MetricName': 'TotalInstanceCount',
                'Value': total_count
            }
        ]
    )
    
    return {'statusCode': 200, 'body': f'Processed instance {instance_id}. Total count: {total_count}'}
